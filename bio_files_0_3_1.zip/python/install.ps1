maturin build
pip install .